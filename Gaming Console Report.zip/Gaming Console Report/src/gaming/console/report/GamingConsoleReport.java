/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gaming.console.report;

/**
 *
 * @author Student
 */
public class GamingConsoleReport {

    public static void main(String[] args) {
        //Array containing sales
        int[][] sales ={
        {1000, 2000, 3000};
        {2000, 3000, 4000};
        {1500, 1100, 1200};
        };    
        // Consoles
        String[] console = {
        "PS5"
        "XBOX"
        "SWITCH"
    };
        
        // Cities
        String[] cities = {
        "Cape Town"
        "Port Elizabeth"
        "Pretoria"
        };
        
        // Display Heading
        System.out.PrintIn("==============================")
        System.out.PrintIn("GAMING CONSOLE SALES REPORT")
        System.out.PrintIn("==============================")
        
        // Print Column Headings
        System.out.printf("%-18s" "")
        
        for (String cities : cities) {
        System.Out.Printf("8s" city)
};
        System.out.Printf("%10", "Total")
        
        //Yearly Sales
        int[] yeartotals = new int[3];
        
        //Print sales and calculate the totals
        for (int row = 0; row<sales.length; row++) {
        int consoleTotal = 0;
        System.out.println();
}
            
          
    };
    
}
